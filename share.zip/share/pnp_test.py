import os
import sys
import numpy as np
import cv2
from ctypes import *
import math
import random
import serial
from scipy.spatial import KDTree
sys.path.append("./MvImport")
from MvCameraControl_class import *
from imutils import paths
from ultralytics import YOLO
start_num_flag = 0
Distance, Length, Detect_number =0,0,0
# 定义 A4 纸的实际尺寸（单位：像素）
A4_WIDTH = 210  # A4 纸宽度（mm），可以根据实际像素比例调整
A4_HEIGHT = 297  # A4 纸高度（mm）                    
hsv_low_color = np.array([0, 0, 0])  # 红色的 HSV 值
hsv_high_color = np.array([255, 255, 23])  # 红色的 HSV 值
hsv_low_color_a4shape = np.array([0, 0, 56])  # 红色的 HSV 值
hsv_high_color_a4shape = np.array([255, 255, 250])  # 红色的 HSV 值
# 替换相机内参矩阵和畸变系数
camera_matrix = np.array([
    [2427.97923,    0.     ,  711.03146],
    [   0.     , 2429.57253,  570.65359],
    [   0.     ,    0.     ,    1.     ]
], dtype=np.float32)
dist_coeffs = np.array([-0.060011, 0.107049, 0.001092, 0.000963, 0.000000], dtype=np.float32)
# 模型权重路径
model_path = "./best.pt" 
class_names = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']  # 类别名称列表

def calculate_distance_from_width(pixel_height):
    """
    根据 A4 纸的宽度计算相机到 A4 纸的距离。
    :param pixel_width: A4 纸在图像中的宽度（像素）
    :return: 距离（毫米）
    """
    if pixel_height == 0:
        return None
    # 使用相机内参矩阵中的焦距 fx
    fx = camera_matrix[0, 0]
    distance = (A4_HEIGHT * fx) / pixel_height
    return distance

def detect_a4_height(frame):
    """
    检测 A4 纸的宽度（像素）。
    :param frame: 输入图像
    :return: A4 纸的宽度（像素）
    """
    # 转换为 HSV 颜色空间
    hsv_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower_red1 = np.array(hsv_low_color)
    upper_red1 = np.array(hsv_high_color)

    # 提取
    mask1 = cv2.inRange(hsv_frame, lower_red1, upper_red1)
    # 查找轮廓
    contours, _ = cv2.findContours(mask1, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    rectangles = []
    if contours:
        # 找到面积最大的轮廓
        largest_contour = max(contours, key=cv2.contourArea)
        # 近似多边形
        epsilon = 0.02 * cv2.arcLength(largest_contour, True)
        approx = cv2.approxPolyDP(largest_contour, epsilon, True)

        # 如果近似多边形有4个顶点，且是闭合的，则认为是矩形
        if len(approx) == 4 and cv2.isContourConvex(approx):
            rectangles.append(approx)
            x, y, w, h = cv2.boundingRect(approx)
            # 假设宽度大于高度的是 A4 纸的宽
            if h > w:
                return x,y,w,h  # 返回 A4 纸的宽度（像素）

    return 0,0,0,0  # 未检测到 A4 纸

# 设置各种类型节点参数
def set_Value(cam, param_type="int_value", node_name="PayloadSize", node_value=None):
    """
    :param cam:               相机实例
    :param param_type:        需要设置的节点值得类型
        int:
        float:
        enum:     参考于客户端中该选项的 Enum Entry Value 值即可
        bool:     对应 0 为关，1 为开
        string:   输入值为数字或者英文字符，不能为汉字
    :param node_name:         需要设置的节点名
    :param node_value:        设置给节点的值
    :return:
    """
    if param_type == "int_value":
        stParam = int(node_value)
        ret = cam.MV_CC_SetIntValueEx(node_name, stParam)
        if ret != 0:
            print("设置 int 型数据节点 %s 失败 ! 报错码 ret[0x%x]" % (node_name, ret))
            sys.exit()
        print("设置 int 型数据节点 %s 成功 ！设置值为 %s !" % (node_name, node_value))

    elif param_type == "float_value":
        stFloatValue = float(node_value)
        ret = cam.MV_CC_SetFloatValue(node_name, stFloatValue)
        if ret != 0:
            print("设置 float 型数据节点 %s 失败 ! 报错码 ret[0x%x]" % (node_name, ret))
            sys.exit()
        print("设置 float 型数据节点 %s 成功 ！设置值为 %s !" % (node_name, node_value))

    elif param_type == "enum_value":
        stEnumValue = node_value
        ret = cam.MV_CC_SetEnumValue(node_name, stEnumValue)
        if ret != 0:
            print("设置 enum 型数据节点 %s 失败 ! 报错码 ret[0x%x]" % (node_name, ret))
            sys.exit()
        print("设置 enum 型数据节点 %s 成功 ！设置值为 %s !" % (node_name, node_value))

    elif param_type == "bool_value":
        ret = cam.MV_CC_SetBoolValue(node_name, node_value)
        if ret != 0:
            print("设置 bool 型数据节点 %s 失败 ！ 报错码 ret[0x%x]" % (node_name, ret))
            sys.exit()
        print("设置 bool 型数据节点 %s 成功 ！设置值为 %s !" % (node_name, node_value))

    elif param_type == "string_value":
        stStringValue = str(node_value)
        ret = cam.MV_CC_SetStringValue(node_name, stStringValue)
        if ret != 0:
            print("设置 string 型数据节点 %s 失败 ! 报错码 ret[0x%x]" % (node_name, ret))
            sys.exit()
        print("设置 string 型数据节点 %s 成功 ！设置值为 %s !" % (node_name, node_value))

class Camera:
    #初始化
    def __init__(self):
        ...
    #打开相机
    def _open(self):
        ...
    #关闭相机
    def _close(self):
        ...
    #获取图像数据
    def get_img(self):
        ...

    def __init__(self,camera_index):
        """
        初始化参数
        :param camera_index:相机索引，未装驱动电脑索引从0开始，装了驱动的从1开始
        """
        #设备信息表初始化
        self._deviceList = MV_CC_DEVICE_INFO_LIST()
 
        #设备类型
        self._tlayerType = MV_USB_DEVICE
 
        #相机实例
        self._cam = MvCamera()
 
        #相机参数
        self._stParam = None
 
        #数据包大小
        self._nPayloadSize = None
 
        #数据流
        self._data_buf = None
 
        #相机索引
        self._camera_index = camera_index
 
        #相机型号等打印
        self._Show_info = True
 
        #获取设备信息
        MvCamera.MV_CC_EnumDevices(self._tlayerType, self._deviceList)
        
        # #打印设备信息
        # if self._Show_info:
        #     self._print_debug_info()
        
        #打开相机流
        self._open()

    def _print_debug_info(self):
        mvcc_dev_info = cast(self._deviceList.pDeviceInfo[self._camera_index], POINTER(MV_CC_DEVICE_INFO)).contents
        if mvcc_dev_info.nTLayerType == MV_USB_DEVICE:
            print("\n设备列表: [%d]" % self._camera_index)
            strModeName = ""
            for per in mvcc_dev_info.SpecialInfo.stUsb3VInfo.chModelName:
                if per == 0:
                    break
                strModeName = strModeName + chr(per)
            print("设备名称: %s" % strModeName)
 
            strSerialNumber = ""
            for per in mvcc_dev_info.SpecialInfo.stUsb3VInfo.chSerialNumber:
                if per == 0:
                    break
                strSerialNumber = strSerialNumber + chr(per)
            print("串行代号: %s" % strSerialNumber)

    def _open(self):
        """
        打开设备
        :return: 
        """
        if int(self._camera_index) >= self._deviceList.nDeviceNum:
            print("索引相机失败!")
            sys.exit()
 
        #创建相机实例
 
        stDeviceList = cast(self._deviceList.pDeviceInfo[int(self._camera_index)], POINTER(MV_CC_DEVICE_INFO)).contents
        ret = self._cam.MV_CC_CreateHandle(stDeviceList)
        if ret != 0:
            print("相机打开错误: 相机索引创建句柄失败! 错误码:[0x%x]" % ret)
            sys.exit()
 
        #打开设备
        ret = self._cam.MV_CC_OpenDevice(MV_ACCESS_Exclusive, 0)
        if ret != 0:
            print("相机打开错误: 设备打开失败! 错误码:[0x%x]" % ret)
            sys.exit()
 
        ret = self._cam.MV_CC_SetEnumValue("TriggerMode", MV_TRIGGER_MODE_OFF)
        if ret != 0:
            print("相机打开错误: 触发模式设置失败! 错误码:[0x%x] ret[0x%x]" % ret)
            sys.exit()
 
        #获取数据包大小
        self._stParam = MVCC_INTVALUE()
        memset(byref(self._stParam), 0, sizeof(MVCC_INTVALUE))
 
        ret = self._cam.MV_CC_GetIntValue("PayloadSize", self._stParam)
        if ret != 0:
            print("相机打开错误: 数据包大小获取失败! 错误码:[0x%x]" % ret)
            sys.exit()
        self._nPayloadSize = self._stParam.nCurValue
 
        # ch:开始取流 | en:Start grab image
        ret = self._cam.MV_CC_StartGrabbing()
        if ret != 0:
            print("取流失败: 开始取流失败! 错误码:[0x%x]" % ret)
            sys.exit()
    
    def get_img(self):
        """
        获取一帧图像
        :return: 
        """
        #创建图像信息表
        stDeviceList = MV_FRAME_OUT_INFO_EX()
        
        #初始化图像信息表
        memset(byref(stDeviceList), 0, sizeof(stDeviceList))
        
        #创建原始图像信息表
        self._data_buf = (c_ubyte * self._nPayloadSize)()
        
        #采用超时机制获取一帧图片，SDK内部等待直到有数据时返回
        ret = self._cam.MV_CC_GetOneFrameTimeout(byref(self._data_buf), self._nPayloadSize, stDeviceList, 1000)
        if ret == 0:
            # print("get one frame: Width[%d], Height[%d], nFrameNum[%d]" % (stDeviceList.nWidth, stDeviceList.nHeight, stDeviceList.nFrameNum))
            
            #配置图像参数
            nRGBSize = stDeviceList.nWidth * stDeviceList.nHeight * 3
            stConvertParam = MV_SAVE_IMAGE_PARAM_EX()
            stConvertParam.nWidth = stDeviceList.nWidth
            stConvertParam.nHeight = stDeviceList.nHeight
            stConvertParam.pData = self._data_buf
            stConvertParam.nDataLen = stDeviceList.nFrameLen
            stConvertParam.enPixelType = stDeviceList.enPixelType
            stConvertParam.nImageLen = stConvertParam.nDataLen
            stConvertParam.nJpgQuality = 70
            stConvertParam.enImageType = MV_Image_Jpeg
            stConvertParam.pImageBuffer = (c_ubyte * nRGBSize)()
            stConvertParam.nBufferSize = nRGBSize
            ret = self._cam.MV_CC_SetFloatValue("ExposureTime", 50000)  # 设置曝光时间为20毫秒
            
            # ret = cam.MV_CC_ConvertPixelType(stConvertParam)
            # print(stConvertParam.nImageLen)
            
            #覆盖上一帧图像
            ret = self._cam.MV_CC_SaveImageEx2(stConvertParam)
            if ret != 0:
                print("convert pixel fail ! ret[0x%x]" % ret)
                del self._data_buf
                sys.exit()
            
            #获取图像信息
            img_buff = (c_ubyte * stConvertParam.nImageLen)()
            # 替换这一行：
            # cdll.msvcrt.memcpy(byref(img_buff), stConvertParam.pImageBuffer, stConvertParam.nImageLen)

            # 改为：
            libc = ctypes.CDLL("libc.so.6")  # Linux 的标准 C 库
            libc.memcpy(byref(img_buff), stConvertParam.pImageBuffer, stConvertParam.nImageLen)

            # 将 ctypes 数组转换为 NumPy 数组
            _img_array = np.frombuffer(img_buff, dtype=np.uint8)

            # 使用 cv2.imdecode 解码图像
            _image = cv2.imdecode(_img_array, cv2.IMREAD_COLOR)

            return _image
    def _close(self):
 
        ret = self._cam.MV_CC_StopGrabbing()
        if ret != 0:
            print("相机关闭失败: 停止取流失败! 错误码:[0x%x]" % ret)
            del self._data_buf
            sys.exit()
 
 
        ret = self._cam.MV_CC_CloseDevice()
        if ret != 0:
            print("相机关闭失败: 设别关闭失败! 错误码:[0x%x]" % ret)
            del self._data_buf
            sys.exit()
 
 
        ret = self._cam.MV_CC_DestroyHandle()
        if ret != 0:
            print("相机关闭失败: 句柄销毁失败! 错误码:[0x%x]" % ret)
            del self._data_buf
            sys.exit()
 
        del self._data_buf

def get_perspective_transform_matrix(pixel_x, pixel_y, pixel_width, pixel_heigh, x, y, A4_WIDTH, A4_HEIGHT, img):
    """
    计算透视变换矩阵。

    参数:
        pixel_x (int): A4 纸在图像中的左上角 x 坐标。
        pixel_y (int): A4 纸在图像中的左上角 y 坐标。
        pixel_width (int): A4 纸在图像中的宽度（像素）。
        pixel_heigh (int): A4 纸在图像中的高度（像素）。
        x (int): ROI 区域的左上角 x 坐标。
        y (int): ROI 区域的左上角 y 坐标。
        A4_WIDTH (int): A4 纸的实际宽度（目标图像宽度）。
        A4_HEIGHT (int): A4 纸的实际高度（目标图像高度）。
        img (numpy.ndarray): 输入图像。

    返回:
        M (numpy.ndarray): 透视变换矩阵。
        original_copy (numpy.ndarray): 原图像的副本。
    """
    if pixel_width > 0 and pixel_heigh > 0:
        # 在原图像的副本上裁剪 A4 区域
        original_copy = img.copy()

        # 计算裁剪区域在原图像中的坐标
        crop_x1 = x + pixel_x
        crop_y1 = y + pixel_y
        crop_x2 = crop_x1 + pixel_heigh
        crop_y2 = crop_y1 + pixel_width

        # 定义源点（A4 纸在原图像中的四个角点）
        src_points = np.array([
            [crop_x1, crop_y1],  # 左上角
            [crop_x2, crop_y1],  # 右上角
            [crop_x2, crop_y2],  # 右下角
            [crop_x1, crop_y2]   # 左下角
        ], dtype=np.float32)

        # 定义目标矩形的四个角点
        dst_points = np.array([
            [0, 0],  # 左上角
            [A4_WIDTH, 0],  # 右上角
            [A4_WIDTH - 1, A4_HEIGHT - 1],  # 右下角
            [0, A4_HEIGHT - 1]  # 左下角
        ], dtype=np.float32)

        # 计算透视变换矩阵
        M = cv2.getPerspectiveTransform(src_points, dst_points)
        return M, original_copy
    else:
        return None, None
def remove_black_border(frame):
    """
    检测 A4 纸的宽度（像素）。
    :param frame: 输入图像
    :return: A4 纸的宽度（像素）
    """
    # 转换为 HSV 颜色空间
    hsv_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    lower_red1 = np.array(hsv_low_color_a4shape)
    upper_red1 = np.array(hsv_high_color_a4shape)

    # 提取
    mask1 = cv2.inRange(hsv_frame, lower_red1, upper_red1)
    # 查找轮廓
    contours, _ = cv2.findContours(mask1, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    rectangles = []
    if contours:
        # 找到面积最大的轮廓
        largest_contour = max(contours, key=cv2.contourArea)
        # 近似多边形
        epsilon = 0.02 * cv2.arcLength(largest_contour, True)
        approx = cv2.approxPolyDP(largest_contour, epsilon, True)

        # 如果近似多边形有4个顶点，且是闭合的，则认为是矩形
        if len(approx) == 4 and cv2.isContourConvex(approx):
            rectangles.append(approx)
            x, y, w, h = cv2.boundingRect(approx)
            # 绘制轮廓
            # cv2.drawContours(frame, rectangles, -1, (255, 255, 0), 1)
            result = frame[x:x+h, y:y+w]  # 裁剪出 A4 纸区域
            # 假设宽度大于高度的是 A4 纸的宽
            if h > w:
                mask = 255 * np.ones(frame.shape[:2], dtype=np.uint8)  # 创建白色背景
                cv2.drawContours(mask, rectangles, -1, (0), thickness=cv2.FILLED)  # 在白色背景上绘制黑色掩码
                inverted_mask = cv2.bitwise_not(mask)  # 反转掩码
                result = cv2.bitwise_and(frame, frame, mask=inverted_mask)  # 应用反转后的掩码
                white_background = 255 * np.ones_like(frame)  # 创建白色背景图像
                result = cv2.add(result, cv2.bitwise_and(white_background, white_background, mask=mask))  # 将白色背景与结果合并
                # cv2.imshow('A4 Paper Detected', result)
                return result
    return None  # 未检测到 A4 纸
def base(a4):
    global Length
    # 在透视变换后，计算 cm_per_pixel
    real_height_cm = 29.7  # A4纸的实际高度（cm）
    warped_height_pixels = a4.shape[0]  # 变换后图像的高度（像素）
    cm_per_pixel_height = real_height_cm / warped_height_pixels
    cm_per_pixel = cm_per_pixel_height # 取平均值
    gray = cv2.cvtColor(a4, cv2.COLOR_BGR2GRAY)
    _, binary = cv2.threshold(gray, 30, 250, cv2.THRESH_BINARY_INV)
    contours_a4, hierarchy = cv2.findContours(binary, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)

    for i, contour in enumerate(contours_a4):
        area = cv2.contourArea(contour)
        if area > 1000:
            perimeter = cv2.arcLength(contour, True)
            approx = cv2.approxPolyDP(contour, 0.015 * perimeter, True)
            CornerNum = len(approx)
            is_hollow = False
            if hierarchy[0][i][2] != -1:
                is_hollow = True

            (_, _), radius = cv2.minEnclosingCircle(contour)
            min_circle_area = 3.14 * (radius ** 2)
            density = area / min_circle_area
            cv2.imshow('mask', binary)
            if not is_hollow and density > 0.3:
                if CornerNum == 3:
                    # ============= 等边三角形检测优化开始 =============                    
                    # 亚像素级角点检测
                    corners = np.float32([point[0] for point in approx])
                    criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 200, 0.0001)
                    cv2.cornerSubPix(gray, corners, (5, 5), (-1, -1), criteria)
                    
                    # 计算边长并校验等边性
                    edges = []
                    for j in range(3):
                        pt1 = corners[j]
                        pt2 = corners[(j + 1) % 3]
                        edge_length = np.linalg.norm(pt1 - pt2)
                        edges.append(edge_length)
                elif CornerNum == 4:
                    edges = []
                    for j in range(CornerNum):
                        pt1 = approx[j][0]
                        pt2 = approx[(j + 1) % CornerNum][0]
                        edge_length = ((pt1[0] - pt2[0]) ** 2 + (pt1[1] - pt2[1]) ** 2) ** 0.5
                        edges.append(edge_length)
                    # 转换为实际长度（mm）
                    real_edges = [edge * cm_per_pixel for edge in edges]
                    avg_edge = sum(real_edges) / 4
                    Length = np.round(avg_edge, 1)
                elif CornerNum > 4:
                    ellipse = cv2.fitEllipse(contour)
                    (_, _), (major_axis, minor_axis), angle = ellipse

                    # 使用最小二乘法拟合圆形
                    radius = (2*major_axis - minor_axis)/ 2  # 圆的半径
                    diameter_cm = radius* 2 * cm_per_pixel  # 圆的直径（cm）
                    Length = np.round(diameter_cm,1)
        cv2.imshow('mask_a4', a4)
    

def merge_close_points(points, threshold=1.0):
    """合并距离过近的点，解决一个点被识别为两个点的问题"""
    if len(points) < 2:
        return points

    # 将点转换为列表以便修改
    points = points.tolist()
    merged = True

    while merged:
        merged = False
        i = 0
        while i < len(points) - 1:
            j = i + 1
            while j < len(points):
                dist = math.sqrt((points[i][0] - points[j][0]) ** 2 +
                                 (points[i][1] - points[j][1]) ** 2)
                if dist < threshold:
                    # 合并两个点（取平均值）
                    avg_x = int((points[i][0] + points[j][0]) / 2)
                    avg_y = int((points[i][1] + points[j][1]) / 2)
                    points[i] = [avg_x, avg_y]
                    del points[j]
                    merged = True
                else:
                    j += 1
            i += 1

    # 检查首尾点是否过近
    if len(points) > 2:
        first = points[0]
        last = points[-1]
        dist = math.sqrt((first[0] - last[0]) ** 2 + (first[1] - last[1]) ** 2)
        if dist < threshold:
            avg_x = int((first[0] + last[0]) / 2)
            avg_y = int((first[1] + last[1]) / 2)
            points[0] = [avg_x, avg_y]
            points.pop()

    return np.array(points, dtype=np.int32)
# 自定义直角检测函数
# 自定义直角检测函数
def is_right_angle(p1, p2, p3, tolerance=25):
    """
    判断三个点是否构成直角
    p2是顶点
    tolerance: 角度容差（度）
    """
    # 计算两个向量
    vec1 = (p1[0] - p2[0], p1[1] - p2[1])
    vec2 = (p3[0] - p2[0], p3[1] - p2[1])

    # 计算点积和模
    dot_product = vec1[0] * vec2[0] + vec1[1] * vec2[1]
    mod1 = math.sqrt(vec1[0] ** 2 + vec1[1] ** 2)
    mod2 = math.sqrt(vec2[0] ** 2 + vec2[1] ** 2)

    # 避免除以零
    if mod1 == 0 or mod2 == 0:
        print(f"零向量问题：mod1={mod1}, mod2={mod2}")
        return False, 0

    # 计算余弦值并限制在 [-1, 1] 范围内
    cos_theta = dot_product / (mod1 * mod2)
    cos_theta = max(-1, min(1, cos_theta))  # 限制范围

    # 计算角度（度）
    angle = math.degrees(math.acos(cos_theta))

    # 判断是否接近90度
    return abs(angle - 90) < tolerance, angle

def performance(num_flag,a4):
    global Length
    matches = []  # 存储匹配结果
    margin = 20  # 匹配时的容差
    length=[]
    squares = []
    detected_numbers = []
    reconstructed_squares = []
    a4 = remove_black_border(a4)
    if a4 is not None:
        gray = cv2.cvtColor(a4, cv2.COLOR_BGR2GRAY)
        _, binary = cv2.threshold(gray, 30, 250, cv2.THRESH_BINARY_INV)
        if num_flag:
            detected_numbers.extend(predict_num(model_path, binary, class_names))
        contours_a4, _ = cv2.findContours(binary, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        # 在透视变换后，计算 cm_per_pixel
        real_width_cm = 29.7  # A4纸的实际宽度（cm）
        real_height_cm = 21.0  # A4纸的实际高度（cm）
        warped_width_pixels = a4.shape[1]  # 变换后图像的宽度（像素）
        warped_height_pixels = a4.shape[0]  # 变换后图像的高度（像素）

        cm_per_pixel_width = real_width_cm / warped_width_pixels
        cm_per_pixel_height = real_height_cm / warped_height_pixels
        cm_per_pixel = (cm_per_pixel_width + cm_per_pixel_height) / 2  # 取平均值

        for i, contour in enumerate(contours_a4):
            area = cv2.contourArea(contour)
            if area > 1000:
                perimeter = cv2.arcLength(contour, True)
                approx = cv2.approxPolyDP(contour, 0.02*perimeter, True)
                CornerNum = len(approx)

                x, y, w, h = cv2.boundingRect(approx)
                _, _, radius = cv2.minEnclosingCircle(contour)
                min_circle_area = 3.14 * (radius ** 2)
                density = area / min_circle_area

                if density > 0.35:
                    if CornerNum == 4:
                        # 使用最小外接矩形计算边长
                        rect = cv2.minAreaRect(contour)
                        box = cv2.boxPoints(rect)
                        box = np.int0(box)
                        # 计算最小外接矩形的宽度和高度
                        width = rect[1][0] * cm_per_pixel
                        height = rect[1][1] * cm_per_pixel
                        side_length_cm = min(width, height)  # 取较小值作为边长
                        if side_length_cm > 17:
                            continue  # 舍去边长大于 16cm 的正方形
                        else:
                            edges = []
                            for j in range(CornerNum):
                                pt1 = approx[j][0]
                                pt2 = approx[(j + 1) % CornerNum][0]
                                edge_length = ((pt1[0] - pt2[0]) ** 2 + (pt1[1] - pt2[1]) ** 2) ** 0.5
                                edges.append(edge_length)
                            # 转换为实际长度（mm）
                            real_edges = [edge * cm_per_pixel for edge in edges]
                            avg_edge = sum(real_edges) / 4
                            length.append(avg_edge)
                            if num_flag==1:
                                squares.append({"id": len(squares) + 1, "rect": (x, y, w, h), "length": avg_edge})
                    elif CornerNum > 4:
                        # 计算边长（以 cm 为单位）
                        side_length_cm = h * cm_per_pixel
                        if side_length_cm > 20 and side_length_cm < 6:
                            continue  # 舍去边长大于 16cm 的正方形
                        # =================================
                        # 策略1: 轮廓点分析（所有点）
                        # =================================
                        # 解决点重叠问题 - 合并距离过近的点
                        corners = np.float32([point[0] for point in approx])
                        contour_points = merge_close_points(corners, threshold=0.5)
                        n = len(contour_points)
                        # 添加首尾点形成循环（扩展为4个点用于方向一致性检查）
                        extended_points = np.vstack([contour_points, contour_points[:4]])
                        strategy1_angles = []
                        non_right_angles = []  # 存储非直角点信息 (点位置, 角度)
                        real_length=[]
                        # 按顺序处理所有点
                        for i in range(0, n):
                            p1 = tuple(extended_points[i])
                            p2 = tuple(extended_points[(i + 1) % n])
                            p3 = tuple(extended_points[(i + 2) % n])
                            p4 = tuple(extended_points[(i + 3) % n])  # 引入第四个点用于方向一致性检查
                            # 检查是否直角
                            is_right, actual_angle = is_right_angle(p1, p2, p3)
                            is_right1, _ = is_right_angle(p2, p3, p4)
                            if is_right and is_right1:
                                # 新增方向一致性检查
                                dir_consistent = False
                                # 计算向量P2->P1和P3->P4
                                vec1 = (p1[0] - p2[0], p1[1] - p2[1])  # P2->P1
                                vec2 = (p4[0] - p3[0], p4[1] - p3[1])  # P3->P4
                                # 计算向量模（避免除零）
                                mod1 = math.sqrt(vec1[0] ** 2 + vec1[1] ** 2)
                                mod2 = math.sqrt(vec2[0] ** 2 + vec2[1] ** 2)
                                if mod1 > 0 and mod2 > 0:
                                    # 单位化向量
                                    unit_vec1 = (vec1[0] / mod1, vec1[1] / mod1)
                                    unit_vec2 = (vec2[0] / mod2, vec2[1] / mod2)
                                    # 计算点积（余弦值）
                                    dot_product = unit_vec1[0] * unit_vec2[0] + unit_vec1[1] * unit_vec2[1]
                                    # 设置方向一致性阈值（0.95表示方向基本一致）
                                    dir_consistent = dot_product > 0.95
                                # 仅在方向一致时标记为有效直角
                                if dir_consistent:
                                    strategy1_angles.append(p2)
                                    # 计算 p2 和 p3 之间的距离
                                    real_length_cm = math.sqrt((p3[0] - p2[0]) ** 2 + (p3[1] - p2[1]) ** 2) * cm_per_pixel
                                    if real_length_cm > 5 and real_length_cm < 14:
                                        real_length.append(real_length_cm)
                                        # 重建正方形
                                        # 计算垂直方向向量
                                        direction = (p3[0] - p2[0], p3[1] - p2[1])
                                        perpendicular_cw = (-direction[1], direction[0])  # 顺时针旋转90度
                                        perpendicular_ccw = (direction[1], -direction[0])  # 逆时针旋转90度

                                        # 单位化垂直方向向量
                                        perpendicular_cw_length = math.sqrt(perpendicular_cw[0] ** 2 + perpendicular_cw[1] ** 2)
                                        unit_perpendicular_cw = (perpendicular_cw[0] / perpendicular_cw_length, perpendicular_cw[1] / perpendicular_cw_length)

                                        perpendicular_ccw_length = math.sqrt(perpendicular_ccw[0] ** 2 + perpendicular_ccw[1] ** 2)
                                        unit_perpendicular_ccw = (perpendicular_ccw[0] / perpendicular_ccw_length, perpendicular_ccw[1] / perpendicular_ccw_length)

                                        # 重建四个方向的正方形
                                        possible_squares = []

                                        # 顺时针方向
                                        p4_cw = (int(p3[0] + unit_perpendicular_cw[0] * real_length_cm / cm_per_pixel),
                                                int(p3[1] + unit_perpendicular_cw[1] * real_length_cm / cm_per_pixel))
                                        p1_cw = (int(p2[0] + unit_perpendicular_cw[0] * real_length_cm / cm_per_pixel),
                                                int(p2[1] + unit_perpendicular_cw[1] * real_length_cm / cm_per_pixel))
                                        square_cw = np.array([p2, p3, p4_cw, p1_cw], dtype=np.int32)
                                        possible_squares.append(square_cw)

                                        # 逆时针方向
                                        p4_ccw = (int(p3[0] + unit_perpendicular_ccw[0] * real_length_cm / cm_per_pixel),
                                                int(p3[1] + unit_perpendicular_ccw[1] * real_length_cm / cm_per_pixel))
                                        p1_ccw = (int(p2[0] + unit_perpendicular_ccw[0] * real_length_cm / cm_per_pixel),
                                                int(p2[1] + unit_perpendicular_ccw[1] * real_length_cm / cm_per_pixel))
                                        square_ccw = np.array([p2, p3, p4_ccw, p1_ccw], dtype=np.int32)
                                        possible_squares.append(square_ccw)

                                        # 校验每个正方形的有效性
                                        best_square = None
                                        best_white_pixel_ratio = 0.5

                                        for square_points in possible_squares:
                                            # 绘制正方形框线（不填充）
                                            cv2.polylines(binary, [square_points], isClosed=True, color=255, thickness=1)

                                            # 获取正方形的边界框
                                            x, y, w, h = cv2.boundingRect(square_points)

                                            # 裁剪出正方形框内的区域
                                            roi_binary = binary[y:y + h, x:x + w]

                                            # 统计框内的总像素数和白色像素数
                                            total_pixels = roi_binary.size
                                            white_pixels = np.sum(roi_binary > 0)

                                            # 计算白色像素的面积占比
                                            if total_pixels > 0:
                                                white_pixel_ratio = white_pixels / total_pixels
                                            else:
                                                white_pixel_ratio = 0
                                            # 判断是否为最优正方形
                                            if white_pixel_ratio > best_white_pixel_ratio:
                                                best_white_pixel_ratio = white_pixel_ratio
                                                best_square = square_points

                                        # 输出结果
                                        if best_square is not None:
                                            # 计算每条边的长度
                                            edges = [
                                                np.linalg.norm(square_points[0] - square_points[1]),  # 边 p2 -> p3
                                                np.linalg.norm(square_points[1] - square_points[2]),  # 边 p3 -> p4
                                                np.linalg.norm(square_points[2] - square_points[3]),  # 边 p4 -> p1
                                                np.linalg.norm(square_points[3] - square_points[0])   # 边 p1 -> p2
                                            ]
                                            avg_edge = sum(edges) / 4 * cm_per_pixel  # 取平均值作为边长
                                            if num_flag==1:
                                                reconstructed_squares.append({"id": len(reconstructed_squares) + 1, "rect": (x, y, w, h), "length": avg_edge})
                                            else:
                                                length.append(avg_edge)
                                            cv2.polylines(a4, [best_square], isClosed=True, color=(255, 255, 255), thickness=10)
                                        else:
                                            print("No valid square found.")
                                else:
                                    # 方向不一致时视为非直角
                                    non_right_angles.append((p2, actual_angle))
                            else:
                                # 添加非直角信息并存储
                                non_right_angles.append((p2, actual_angle))
        cv2.imshow('a4', a4)
        if num_flag==1:
            for number in detected_numbers:
                cx, cy = number["center"]
                for square in squares:
                    x, y, w, h = square["rect"]
                    if (x - margin) <= cx <= (x + w + margin) and (y - margin) <= cy <= (y + h + margin):
                        matches.append({"number": number["label"], "square_id": square["id"], "square_length": square["length"]})
                        break  # 一个数字只匹配一个正方形
                for reconstructed_square in reconstructed_squares:
                    x, y, w, h = reconstructed_square["rect"]
                    if (x - margin) <= cx <= (x + w + margin) and (y - margin) <= cy <= (y + h + margin):
                        matches.append({"number": number["label"], "square_id": square["id"], "square_length": square["length"]})
                        break  # 一个数字只匹配一个正方形
            for match in matches:
                print(f"数字 {match['number']} 边长为 {match['square_length']:.1f} cm")
            return matches
        elif num_flag==2:
            if len(length)>0:
                Length = random.choice(length)
            return None
        else:
            if len(length)>0:
                Length = min(length)
            return None
    else:
        return None
def predict_num(model_path, frame,class_names):
    """
    使用摄像头实时预测。

    Args:
        model_path (str): YOLO 模型权重路径。
        class_names (list): 类别名称列表。
    """
    detected_numbers = []  # 存储所有检测到的数字
    # 将灰度图像转换为三通道图像
    frame = cv2.cvtColor(frame, cv2.COLOR_GRAY2BGR)
    model = YOLO(model_path)  # 加载 YOLO 模型
    model.overrides['verbose'] = False  # 关闭详细日志
    # 使用 YOLO 模型进行预测
    results = model.predict(source=frame, save=False, conf=0.25)
    for result in results:
        boxes = result.boxes.xyxy  # 获取边界框
        scores = result.boxes.conf  # 获取置信度
        labels = result.boxes.cls  # 获取类别索引

        for box, score, label in zip(boxes, scores, labels):
            if score > 0.5:  # 置信度阈值
                # 获取目标边界框
                x1, y1, x2, y2 = map(int, box)
                # 计算目标中心坐标
                target_cx = (x1 + x2) // 2
                target_cy = (y1 + y2) // 2
                # 绘制目标中心点
                cv2.circle(frame, (target_cx, target_cy), 5, (255, 0, 0), -1)
                # 绘制边界框
                cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                # 绘制类别名称和置信度
                text = f"{class_names[int(label)]} {score:.2f}"
                cv2.putText(frame, text, (x1, y1 - 20), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)
                # 显示结果
                cv2.imshow("YOLO Real-Time Detection", frame)
                detected_numbers.append({"label": class_names[int(label)], "center": (target_cx, target_cy)})
        return detected_numbers
def main():
    global Length, Distance,Detect_number,Mode
    camera = Camera(0)
    # 带参数的串口初始化
    ser = serial.Serial(
        port='/dev/ttyS1',              # 串口号
        baudrate=115200,            # 波特率
        bytesize=serial.EIGHTBITS, # 数据位
        parity=serial.PARITY_NONE, # 校验位
        stopbits=serial.STOPBITS_ONE, # 停止位
        timeout=1,                # 读取超时时间(秒)
        xonxoff=False,            # 软件流控
        rtscts=False,             # 硬件(RTS/CTS)流控
        dsrdtr=False,             # 硬件(DSR/DTR)流控
        write_timeout=1           # 写入超时时间(秒)
    )
    # 检查串口是否打开
    if ser.is_open:
        print(f"串口 {ser.port} 已打开")

    while True:
        line = ser.readline().decode('utf-8').strip()
        if line:
            Mode, Detect_number = map(int, line.split(','))
            # print(Mode,Detect_number)
        img = camera.get_img()
        if img is None:
            print("未捕获到图像")
            break

        img = cv2.resize(img, (1440, 1080))
        x, y, w, h = 300, 100, 800, 800  # 根据需要调整 ROI 的位置和大小
        h_img, w_img = img.shape[:2]
        if x+w > w_img or y+h > h_img:
            print("ROI 超出图像范围")
            break

        roi_img = img[y:y+h, x:x+w]  # 裁剪出 ROI 区域

        # 检测 A4 纸的宽度（像素）
        pixel_x, pixel_y, pixel_heigh, pixel_width = detect_a4_width(roi_img)
        # 显示 ROI 图像
        cv2.imshow('ROI', roi_img)
        # 计算距离
        distance = calculate_distance_from_width(pixel_width)
        print(distance)
        if distance is not None:
            Distance = distance
            cv2.putText(img, f"Distance: {distance/1000:.2f} m", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        else:
            cv2.putText(img, "A4 not detected", (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
        M, original_copy = get_perspective_transform_matrix(
            pixel_x, pixel_y, pixel_width, pixel_heigh, x, y, A4_WIDTH, A4_HEIGHT, img
        )

        if M is not None:
            # 应用透视变换
            warped = cv2.warpPerspective(original_copy, M, (A4_WIDTH, A4_HEIGHT))
            cv2.imshow("Warped", warped)
            # 应用透视变换
            warped = cv2.warpPerspective(original_copy, M, (A4_WIDTH, A4_HEIGHT))
            if Mode == 0:
                start_num_flag = 1
                continue
            elif Mode == 1:
                base(warped, distance)
            elif Mode == 2:
                performance(0,warped)
            elif Mode == 3:
                if start_num_flag == 1:
                    match = performance(1,warped)
                    if(match is not None):
                        for m in match:
                            print(m['number'], Detect_number)
                            if Detect_number == m['number']:
                                Length = m['square_length']
                    start_num_flag = 0
            elif Mode == 4:
                performance(2,warped)
        else:
            print("未检测到有效的 A4 纸区域")
        ser.write((f"{Length:.2f}\n").encode('utf-8'))  # 发送数据到串口
        ser.write((f"{Distance/10:.2f}\n").encode('utf-8'))  # 发送数据到串口
        cv2.imshow('img', img)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    camera.close()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()
