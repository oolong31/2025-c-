import random
from PIL import Image, ImageDraw, ImageFont
import os

# 图片尺寸（像素）
IMG_WIDTH, IMG_HEIGHT = 210, 297

# 方框边长范围（像素）
MIN_BOX_SIZE = 50
MAX_BOX_SIZE = 180
# 距离边缘最小距离（像素）
MARGIN = 10

# 每张图片的方框数量
BOX_COUNT = 3
# 图片数量
IMG_COUNT = 1000

# 定义每个数字的目标数量（注意：键不能重复）
target_counts = {'8': 100, '5': 100,'6': 100,'3':100,'9':100}
current_counts = {key: 0 for key in target_counts}  # 初始化计数器

def generate_random_box():
    box_size = random.randint(MIN_BOX_SIZE, MAX_BOX_SIZE)
    left = random.randint(MARGIN, IMG_WIDTH - MARGIN - box_size)
    top = random.randint(MARGIN, IMG_HEIGHT - MARGIN - box_size)
    right = left + box_size
    bottom = top + box_size
    return (left, top, right, bottom), box_size

def check_overlap(new_box, placed_boxes):
    for placed_box in placed_boxes:
        if not (new_box[2] <= placed_box[0] or  # 新方框的右边 <= 已放置方框的左边
                new_box[0] >= placed_box[2] or  # 新方框的左边 >= 已放置方框的右边
                new_box[3] <= placed_box[1] or  # 新方框的下边 <= 已放置方框的上边
                new_box[1] >= placed_box[3]):   # 新方框的上边 >= 已放置方框的下边
            return True
    return False

# 创建输出目录
os.makedirs("generated_images", exist_ok=True)

for img_idx in range(1, IMG_COUNT + 1):
    # 检查是否已完成所有目标
    if all(current_counts[key] >= target_counts[key] for key in target_counts):
        print("所有目标数量已达成，提前终止")
        break

    # 创建白底图片
    img = Image.new('RGB', (IMG_WIDTH, IMG_HEIGHT), color='black')
    draw = ImageDraw.Draw(img)
    placed_boxes = []  # 用于存储已放置的方框区域

    for _ in range(BOX_COUNT):
        # 检查是否还有未达到目标数量的数字
        available_numbers = [num for num in target_counts if current_counts[num] < target_counts[num]]
        if not available_numbers:
            break

        # 生成不重叠的方框
        overlap = True
        attempts = 0
        while overlap and attempts < 100:  # 防止无限尝试
            new_box, box_size = generate_random_box()
            overlap = check_overlap(new_box, placed_boxes)
            attempts += 1

        if overlap:  # 如果尝试100次仍找不到合适位置，跳过
            continue

        placed_boxes.append(new_box)
        # 创建正方形
        box = Image.new('RGBA', (box_size, box_size), (255, 255, 255, 0))
        box_draw = ImageDraw.Draw(box)
        box_draw.rectangle([0, 0, box_size, box_size], fill='white', outline='white')

        # 随机选择一个未达到目标数量的数字
        number = random.choice(available_numbers)
        current_counts[number] += 1

        # 尝试加载字体（兼容不同系统）
        try:
            font = ImageFont.truetype("times.ttf", int(box_size * 0.6))
        except:
            try:
                font = ImageFont.truetype("arial.ttf", int(box_size * 0.6))
            except:
                font = ImageFont.load_default()

        # 计算文本位置（更精确的居中方法）
        text = str(number)
        bbox = font.getbbox(text)
        text_width = bbox[2] - bbox[0]
        text_height = bbox[3] - bbox[1]
        text_x = (box_size - text_width) // 2
        text_y = (box_size - text_height) // 2

        box_draw.text((text_x, text_y), text, font=font, fill='black')

        # 随机旋转，左倾或右倾45度
        angle = random.choice([-20, 20])
        rotated_box = box.rotate(angle, expand=True, resample=Image.BICUBIC)

        # 粘贴到主图
        img.paste(rotated_box, (new_box[0], new_box[1]), rotated_box)

    # 保存图片
    filename = f"generated_images/non_overlapping_boxes_{img_idx}.png"
    img.save(filename)
    print(f"图片已保存为 {filename}，当前计数: {current_counts}")